# importeer de flask library
from flask import Flask

# Maak een applicatie-object aan
app = Flask(__name__)

# oefening 1
@app.route('/')
def index():
    return

# start de Flask server met debug
if __name__ == '__main__':
    app.run(debug=True)
